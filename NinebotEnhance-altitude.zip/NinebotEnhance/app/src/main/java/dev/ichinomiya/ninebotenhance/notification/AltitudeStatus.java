package dev.ichinomiya.ninebotenhance.notification;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;

/**
 * Reads altitude from GPS (Location) or phone barometer. GPS needs location permission;
 * barometer uses TYPE_PRESSURE and converts via SensorManager.getAltitude with standard sea-level pressure.
 */
public final class AltitudeStatus {
    public record Snapshot(float meters, long elapsed, boolean fromGps, boolean valid) {
        public static final Snapshot EMPTY = new Snapshot(Float.NaN, 0, false, false);
    }

    private final Context context;
    private final Handler worker;
    private volatile Snapshot cached = Snapshot.EMPTY;
    private volatile boolean useGps;
    private volatile boolean listening;
    private LocationManager locationManager;
    private SensorManager sensorManager;
    private Sensor pressureSensor;
    private float lastPressure = Float.NaN;
    private long sampled = -10000;

    private final LocationListener locationListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location != null && location.hasAltitude()) {
                cached = new Snapshot((float) location.getAltitude(), SystemClock.elapsedRealtime(), true, true);
            }
        }
        @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
    };

    private final SensorEventListener sensorListener = new SensorEventListener() {
        @Override public void onSensorChanged(SensorEvent event) {
            if (event != null && event.values != null && event.values.length > 0) {
                lastPressure = event.values[0];
                float alt = SensorManager.getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, lastPressure);
                cached = new Snapshot(alt, SystemClock.elapsedRealtime(), false, true);
            }
        }
        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };

    public AltitudeStatus(Context c) {
        context = c.getApplicationContext();
        HandlerThread thread = new HandlerThread("Ninebot-Altitude", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();
        worker = new Handler(thread.getLooper());
    }

    public synchronized void setUseGps(boolean gps) {
        if (useGps == gps) return;
        useGps = gps;
        stopListening();
        startListening();
    }

    public synchronized Snapshot snapshot() {
        long now = SystemClock.elapsedRealtime();
        if (!listening && now - sampled >= 2000) {
            sampled = now;
            startListening();
        }
        Snapshot s = cached;
        if (s.valid && now - s.elapsed > 15000) return Snapshot.EMPTY;
        return s;
    }

    private void startListening() {
        if (listening) return;
        worker.post(() -> {
            try {
                if (useGps) {
                    if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        cached = Snapshot.EMPTY;
                        return;
                    }
                    locationManager = context.getSystemService(LocationManager.class);
                    if (locationManager == null) return;
                    if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1f, locationListener, worker.getLooper());
                        Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (last != null && last.hasAltitude()) {
                            cached = new Snapshot((float) last.getAltitude(), SystemClock.elapsedRealtime(), true, true);
                        }
                    } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5f, locationListener, worker.getLooper());
                    }
                } else {
                    sensorManager = context.getSystemService(SensorManager.class);
                    if (sensorManager == null) return;
                    pressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
                    if (pressureSensor != null) {
                        sensorManager.registerListener(sensorListener, pressureSensor, SensorManager.SENSOR_DELAY_NORMAL, worker);
                    }
                }
                listening = true;
            } catch (RuntimeException ignored) {
                listening = false;
            }
        });
    }

    private void stopListening() {
        worker.post(() -> {
            try {
                if (locationManager != null) {
                    locationManager.removeUpdates(locationListener);
                    locationManager = null;
                }
                if (sensorManager != null && pressureSensor != null) {
                    sensorManager.unregisterListener(sensorListener);
                    sensorManager = null;
                    pressureSensor = null;
                }
            } catch (RuntimeException ignored) {}
            listening = false;
        });
    }

    public void release() {
        stopListening();
    }
}
